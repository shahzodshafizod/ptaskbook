#include <direct.h>
#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

double round(double, int);
float round(float, int);

// { "no": 20, "dat": "", "ans": "" }
void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __foldername__[4];
	char __input_filename__[12];
	char __output_filename__[12];
	sprintf(__foldername__, "%03d", __number__);
	sprintf(__input_filename__, "%s\\%s.dat", __foldername__, __foldername__);
	sprintf(__output_filename__, "%s\\%s.ans", __foldername__, __foldername__);
	_mkdir(__foldername__);
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	output_file << boolalpha;

	// ====code============================================

    Task("Minmax20");
	int N;

	pt >> N;
	input_file << N << endl;

	int number, minimal, maximal, mins = 1, maxs = 1;

	pt >> number;
	input_file << number << ' ';

	minimal = maximal = number;
	for (int i = 2; i <= N; i++)
	{
		pt >> number;
		input_file << number << ' ';

		if (number == maximal)
			maxs++;

		if (number == minimal)
			mins++;

		if (number < minimal)
		{
			minimal = number;
			mins = 1;
		}

		if (number > maximal)
		{
			maximal = number;
			maxs = 1;
		}
	}

	int counts = (mins == N) ? mins : mins + maxs;

	pt << counts;
	output_file << counts;

	// ====code============================================

	input_file.close();
	output_file.close();
}

double round(double number, int precision) {
	double multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	double half = 0.5 / multiplier;
	double temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

float round(float number, int precision) {
	float multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	float half = 0.5 / multiplier;
	float temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}