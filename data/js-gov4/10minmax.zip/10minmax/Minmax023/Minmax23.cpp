#include <direct.h>
#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

void SortKam(double&, double&, double&);

// { "no": 23, "dat": "2", "ans": "2" }
void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __foldername__[4];
	char __input_filename__[12];
	char __output_filename__[12];
	sprintf(__foldername__, "%03d", __number__);
	sprintf(__input_filename__, "%s\\%s.dat", __foldername__, __foldername__);
	sprintf(__output_filename__, "%s\\%s.ans", __foldername__, __foldername__);
	_mkdir(__foldername__);
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << boolalpha << fixed << setprecision(2);

	// ====code============================================


    Task("Minmax23");
	int N;

	pt >> N;
	input_file << N << endl;

	double number, maximal1, maximal2, maximal3;

	pt >> maximal1 >> maximal2 >> maximal3;
	input_file << maximal1 << ' ' << maximal2 << ' ' << maximal3;

	SortKam(maximal1, maximal2, maximal3);

	for (int i = 4; i <= N; i++)
	{
		pt >> number;
		input_file << ' ' << number;

		if (number > maximal3)
			maximal3 = number;

		SortKam(maximal1, maximal2, maximal3);
	}

	pt << maximal1 << maximal2 << maximal3;
	output_file << maximal1 << ' ' << maximal2 << ' ' << maximal3;

	// ====code============================================

	input_file.close();
	output_file.close();
}

void SortKam(double& a, double& b, double& c)
{
	double Small, Great;

	if ( (a > b) && (a > c) )
		Great = a;
	else if (b > c)
		Great = b;
	else
		Great = c;

	if ( (a < b) && (a < c) )
		Small = a;
	else if (b < c)
		Small = b;
	else
		Small = c;

	double sum = a + b + c;
	
	a = Great;
	b = sum - Great - Small;
	c = Small;
}
