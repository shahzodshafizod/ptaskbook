#include <direct.h>
#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

struct Qavs
{
	char q;
	Qavs* prev;
};

void pushQavs(Qavs**, char);
void popQavs(Qavs**);
void Doiravi(Qavs**, char, int, int&);
double round(double, int);
float round(float, int);

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __foldername__[4];
	char __input_filename__[12];
	char __output_filename__[12];
	sprintf(__foldername__, "%03d", __number__);
	sprintf(__input_filename__, "%s\\%s.dat", __foldername__, __foldername__);
	sprintf(__output_filename__, "%s\\%s.ans", __foldername__, __foldername__);
	_mkdir(__foldername__);
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << boolalpha << fixed << setprecision(2);

	// ====code============================================


    Task("String69");
	char str[1000];
	
	pt >> str;
	input_file << str;

	int length = strlen(str);

	Qavs* qavs = NULL;
	int opens = 0, closes = 0, index = -2;
	for (int i = 0; i < length; i++)
	{
		if ( (str[i] == '(') || (str[i] == ')') )
			Doiravi(&qavs, str[i], i, index);		
	}

	index++;

	int result;
	if ( ! qavs )
		result = 0;
	else
		result = index;
	
	pt << result;
	output_file << result;


	// ====code============================================

	input_file.close();
	output_file.close();
}

double round(double number, int precision) {
	double multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	double half = 0.5 / multiplier;
	double temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

float round(float number, int precision) {
	float multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	float half = 0.5 / multiplier;
	float temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

void popQavs(Qavs** qavs)
{
	Qavs* prevQ = (*qavs)->prev;
	
	delete (*qavs);
	
	(*qavs) = prevQ;
}

void pushQavs(Qavs** qavs, char C)
{
	Qavs* newQ = new Qavs;
	newQ->q = C;
	newQ->prev = (*qavs);
	
	(*qavs) = newQ;
}

void Doiravi(Qavs** qavs, char C, int i, int& index)
{
	if (C == '(')
	{
		if (! (*qavs) )
		{
			(*qavs) = new Qavs;
			(*qavs)->q = C;
			(*qavs)->prev = NULL;
		}
		else
			pushQavs(qavs, C);
	}
	else
	{
		if ( (*qavs) && ((*qavs)->q == '(') )
			popQavs(qavs);
		else
		{
			if (index < 0)
				index = i;

			pushQavs(qavs, C);
		}
	}
}
