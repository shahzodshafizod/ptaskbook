#include <direct.h>
#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

double round(double, int);
float round(float, int);

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __foldername__[4];
	char __input_filename__[12];
	char __output_filename__[12];
	sprintf(__foldername__, "%03d", __number__);
	sprintf(__input_filename__, "%s\\%s.dat", __foldername__, __foldername__);
	sprintf(__output_filename__, "%s\\%s.ans", __foldername__, __foldername__);
	_mkdir(__foldername__);
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << boolalpha << fixed << setprecision(2);

	// ====code============================================

    Task("String13");
	char str[1000];

	pt >> str;
	input_file << str;

	int index = 0, digits = 0;
	while (str[index] != '\0')
	{
		digits += (int)((str[index] >= '0') && (str[index] <= '9'));
		index++;
	}

	pt << digits;
	output_file << digits;

	// ====code============================================

	input_file.close();
	output_file.close();
}

double round(double number, int precision) {
	double multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	double half = 0.5 / multiplier;
	double temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

float round(float number, int precision) {
	float multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	float half = 0.5 / multiplier;
	float temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}