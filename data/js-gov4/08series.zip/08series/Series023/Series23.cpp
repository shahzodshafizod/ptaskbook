#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <direct.h>

using namespace std;

// { "no": 23, "dat": "2", "ans": "" }
void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __foldername__[4];
	char __input_filename__[12];
	char __output_filename__[12];
	sprintf(__foldername__, "%03d", __number__);
	sprintf(__input_filename__, "%s\\%s.dat", __foldername__, __foldername__);
	sprintf(__output_filename__, "%s\\%s.ans", __foldername__, __foldername__);
	_mkdir(__foldername__);
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << boolalpha << fixed << setprecision(2);

	// ====code============================================

    Task("Series23");
	int N;

	pt >> N;
	input_file << N << endl;

	double prev, curr, next;

	pt >> prev >> curr;
	input_file << prev << ' ' << curr << ' ';

	int errorIndex = 0;
	for (int i = 3; i <= N; i++)
	{
		pt >> next;
		input_file << next << ' ';

		if ( (errorIndex == 0) && !((curr > prev) && (curr > next) || (curr < prev) && (curr < next)) )
			errorIndex = i-1;
		prev = curr;
		curr = next;
	}

	pt << errorIndex;
	output_file << errorIndex;

	// ====code============================================

	input_file.close();
	output_file.close();
}