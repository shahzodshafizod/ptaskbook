#include <direct.h>
#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <string>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <direct.h>

using namespace std;

void __copy_to_path__(const char* __path__, const char* filenameFrom);
void __copy_here__(const char* fileNameFrom, const char* filenameTo);
char* __get_filename__(const char* filename, const char* suffix);
bool isKitobat(char);
void makeStr(const char* str, char** newStr, int index1, int index2);
void write2file(ofstream& fout, int number1, int width);

template <typename T>
void SwapEnd(T& var)
{
    char* varArray = reinterpret_cast<char*>(&var);
    for(long i = 0; i < static_cast<long>(sizeof(var)/2); i++)
        std::swap(varArray[sizeof(var) - 1 - i],varArray[i]);
}

template <typename T>
void __copy_swapend__(const char* fileNameFrom, const char* fileNameTo, T& number) {
	ifstream ifs(fileNameFrom, ios::binary);
	ofstream ofs(fileNameTo, ios::binary);
	while (true) {
		ifs.read(reinterpret_cast<char*>(&number), sizeof(number));
		if (ifs.eof()) {
			ifs.clear();
			break;
		}
		SwapEnd(number);
		ofs.write(reinterpret_cast<const char*>(&number), sizeof(number));
	}
	ifs.close();
	ofs.close();
}

template <typename T>
void __copy_file__(const char* __path__, const char* fileName, T& number) {
	char* newFileName = __get_filename__(__path__, fileName);
	__copy_to_path__(__path__, fileName);
	__copy_swapend__(fileName, __get_filename__(newFileName, ".big"), number);
}

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __foldername__[4];
	char __input_filename__[12];
	char __output_filename__[12];
	sprintf(__foldername__, "%03d", __number__);
	sprintf(__input_filename__, "%s\\%s.dat", __foldername__, __foldername__);
	sprintf(__output_filename__, "%s\\%s.ans", __foldername__, __foldername__);
	_mkdir(__foldername__);
	ofstream __input_file__(__input_filename__);
	ofstream __output_file__(__output_filename__);
	__input_file__ << fixed << setprecision(2);
	__output_file__ << boolalpha << fixed << setprecision(2);
	char* __path__ = __get_filename__(__foldername__, "\\");
	
	// ====code============================================



    Task("Text40");
	char file1Name[100], file2Name[100], textFileName[100];
	
	pt >> file1Name >> file2Name >> textFileName;
	__input_file__ << file1Name << endl << file2Name << endl << textFileName;
	int shwInt;
	__copy_file__(__path__, file1Name, shwInt);
	__copy_file__(__path__, file2Name, shwInt);

	ifstream file1(file1Name, ios::binary);
	ifstream file2(file2Name, ios::binary);

	ofstream textFile(textFileName);

	int number1, number2;
	while (file1.peek() != -1)
	{
		file1.read(reinterpret_cast<char*>(&number1), sizeof(number1));
		file2.read(reinterpret_cast<char*>(&number2), sizeof(number2));

		//textFile << '|' << setw(30) << number1 << setw(30) << number2 << "|\n";
		
		textFile << '|';
		
		write2file(textFile, number1, 30);
		write2file(textFile, number2, 30);
		
		textFile << "|\n";
	}

	file1.close();
	file2.close();
	textFile.close();

	__copy_to_path__(__path__, textFileName);
	__output_file__ << textFileName;



	// ====code============================================

	__input_file__.close();
	__output_file__.close();
}

void __copy_to_path__(const char* __path__, const char* filenameFrom) {
	
	char* filenameTo = __get_filename__(__path__, filenameFrom);
	__copy_here__(filenameFrom, filenameTo);
}

void __copy_here__(const char* filenameFrom, const char* filenameTo) {
	
	ifstream fileFrom(filenameFrom, ios::binary);
	ofstream fileTo(filenameTo, ios::binary);

	char c;
	while (true) {
		fileFrom.read(reinterpret_cast<char*>(&c), sizeof(c));
		if (fileFrom.eof()) {
			fileFrom.clear();
			break;
		}
		fileTo.write(reinterpret_cast<const char*>(&c), sizeof(c));
	}

	fileFrom.close();
	fileTo.close();
}

char* __get_filename__(const char* filename, const char* suffix) {

	int fLeng = 0; while (filename[fLeng] != '\0') fLeng++;
	
	int sLeng = 0; while (suffix[sLeng] != '\0') sLeng++;

	char* newFilename = new char [fLeng+sLeng+1]; // + for \0
	int index = 0;

	// 1. copy filename;
	for (; index < fLeng; index++) {
		newFilename[index] = filename[index];
	}
	
	// 2. copy suffix;
	int suffixIndex = 0;
	while (suffix[suffixIndex] != '\0') {
		newFilename[index++] = suffix[suffixIndex++];
	}

	newFilename[index] = '\0';
	
	return newFilename;
}

void write2file(ofstream& fout, int number, int width)
{
	int length = 0;
	bool isNegative = false;
	if (number == 0)
		length++;
	else
	{
		if (number < 0)
		{
			isNegative = true;
			length++;
			number *= -1;
		}
		int temp = number;
		while (temp > 0)
		{
			temp /= 10;
			length++;
		}
	}
	for (int i = width-length; i >= 1; i--)
		fout << ' ';
	
	if (isNegative)
		fout << '-';
	fout << number;
}
