#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <direct.h>

using namespace std;

// { "no": 12, "dat": "2", "ans": "2" }
void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __foldername__[4];
	char __input_filename__[12];
	char __output_filename__[12];
	sprintf(__foldername__, "%03d", __number__);
	sprintf(__input_filename__, "%s\\%s.dat", __foldername__, __foldername__);
	sprintf(__output_filename__, "%s\\%s.ans", __foldername__, __foldername__);
	_mkdir(__foldername__);
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << fixed << setprecision(2);

	// ====code============================================

    Task("Case12");
	const double PI = 3.14;
	int index;

	pt >> index;
	input_file << index << endl;

	double value, R, D, L, S;

	pt >> value;
	input_file << value;

	switch (index)
	{
		case 1:
			R = value;
			D = 2 * R;
			L = 2 * PI * R;
			S = PI * R * R;
			break;
		case 2:
			D = value;
			R = D / 2;
			L = 2 * PI * R;
			S = PI * R * R;
			break;
		case 3:
			L = value;
			R = L / (2 * PI);
			D = 2 * R;
			S = PI * R * R;
			break;
		case 4:
			S = value;
			R = sqrt(S / PI);
			D = 2 * R;
			L = 2 * PI * R;
			break;
	}
	
	if (index != 1) {
		pt << R;
		output_file << R << ' ';
	}

	if (index != 2) {
		pt << D;
		output_file << D << ' ';
	}

	if (index != 3) {
		pt << L;
		output_file << L << ' ';
	}

	if (index != 4) {
		pt << S;
		output_file << S << ' ';
	}

	// ====code============================================

	input_file.close();
	output_file.close();
}