#include <direct.h>
#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

double round(double, int);
float round(float, int);

// { "no": 62, "dat": "2", "ans": "2" }
void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __foldername__[4];
	char __input_filename__[12];
	char __output_filename__[12];
	sprintf(__foldername__, "%03d", __number__);
	sprintf(__input_filename__, "%s\\%s.dat", __foldername__, __foldername__);
	sprintf(__output_filename__, "%s\\%s.ans", __foldername__, __foldername__);
	_mkdir(__foldername__);
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << boolalpha << fixed << setprecision(2);

	// ====code============================================

    Task("Array62");
	
	int N;

	pt >> N;
	input_file << N << endl;

	double* A = new double [N];
	int sizeB = 0, sizeC = 0;
	for (int i = 0; i < N; i++)
	{
		pt >> A[i];
		input_file << A[i] << ' ';

		if (A[i] > 0)
			sizeB++;
		else
			sizeC++;
	}

	double* B = new double [sizeB];
	double* C = new double [sizeC];
	for (int indexA = 0, indexB = 0, indexC = 0; indexA < N; indexA++)
		if (A[indexA] > 0)
			B[indexB++] = A[indexA];
		else
			C[indexC++] = A[indexA];

	pt << sizeB;
	output_file << sizeB << endl;
	for (int i = 0; i < sizeB; i++) {
		pt << B[i];
		output_file << B[i] << ' ';
	}

	output_file << endl;

	pt << sizeC;
	output_file << sizeC << endl;
	for (int i = 0; i < sizeC; i++) {
		pt << C[i];
		output_file << C[i] << ' ';
	}

	delete [] A;
	delete [] B;
	delete [] C;
	A = B = C;

	// ====code============================================

	input_file.close();
	output_file.close();
}

double round(double number, int precision) {
	double multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	double half = 0.5 / multiplier;
	double temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

float round(float number, int precision) {
	float multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	float half = 0.5 / multiplier;
	float temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}