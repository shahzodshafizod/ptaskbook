#include <direct.h>
#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

double round(double, int);
float round(float, int);

// { "no": 129, "dat": "", "ans": "" }
void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __foldername__[4];
	char __input_filename__[12];
	char __output_filename__[12];
	sprintf(__foldername__, "%03d", __number__);
	sprintf(__input_filename__, "%s\\%s.dat", __foldername__, __foldername__);
	sprintf(__output_filename__, "%s\\%s.ans", __foldername__, __foldername__);
	_mkdir(__foldername__);
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << boolalpha << fixed << setprecision(2);

	// ====code============================================

    Task("Array129");
	
	int N;

	pt >> N;
	input_file << N << endl;

	int* mass = new int [N];
	for (int i = 0; i < N; i++) {
		pt >> mass[i];
		input_file << mass[i] << ' ';
	}

	int index = 0;
	int element = mass[index];
	int maxElementsIndex = index;
	int maxElements = 1;
	int elements = 1;
	for (int i = 1; i < N; i++)
	{
		if (mass[i] != element)
		{
			if (elements >= maxElements)
			{
				maxElements = elements;
				maxElementsIndex = index;
			}

			index = i;
			element = mass[index];
			elements = 1;
		}
		else
			elements++;
	}
	if (elements >= maxElements)
		maxElementsIndex = index;

	int* temp = new int [N+1];
	int tempIndex = 0;
	
	for (int i = 0; i < maxElementsIndex; i++)
		temp[tempIndex++] = mass[i];

	temp[tempIndex++] = mass[maxElementsIndex];

	for (int i = maxElementsIndex; i < N; i++)
		temp[tempIndex++] = mass[i];

	delete [] mass;
	mass = temp;
	temp = 0;
	N++;

	for (int i = 0; i < N; i++) {
		pt << mass[i];
		output_file << mass[i] << ' ';
	}

	delete [] mass;
	mass = 0;

	// ====code============================================

	input_file.close();
	output_file.close();
}

double round(double number, int precision) {
	double multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	double half = 0.5 / multiplier;
	double temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

float round(float number, int precision) {
	float multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	float half = 0.5 / multiplier;
	float temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}