#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <direct.h>

using namespace std;

double round(double, int);
float round(float, int);
bool IsLeapYear(int Y);
int MonthDays(int M, int Y);
void PrevDate(int& D, int& M, int& Y);

// { "no": 54, "dat": "", "ans": "" }
void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __foldername__[4];
	char __input_filename__[12];
	char __output_filename__[12];
	sprintf(__foldername__, "%03d", __number__);
	sprintf(__input_filename__, "%s\\%s.dat", __foldername__, __foldername__);
	sprintf(__output_filename__, "%s\\%s.ans", __foldername__, __foldername__);
	_mkdir(__foldername__);
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	output_file << boolalpha;

	// ====code============================================


    Task("Proc54");
	int d, m, y;
	for (int i = 1; i <= 3; i++)
	{
		pt >> d >> m >> y;
		input_file << d << ' ' << m << ' ' << y << endl;

		PrevDate(d, m, y);

		pt << d << m << y;
		output_file << d << ' ' << m << ' ' << y << endl;
	}

	// ====code============================================

	input_file.close();
	output_file.close();
}

double round(double number, int precision) {
	double multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	double half = 0.5 / multiplier;
	double temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

float round(float number, int precision) {
	float multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	float half = 0.5 / multiplier;
	float temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

bool IsLeapYear(int Y)
{
	if (Y % 400 == 0)
		return true;

	else if (Y % 100 == 0)
		return false;

	else if (Y % 4 == 0)
		return true;

	else
		return false;
}

int MonthDays(int M, int Y)
{
	switch (M)
	{
		case 1: case 3: case 5: case 7: case 8: case 10: case 12:
			return 31;
		case 4: case 6: case 9: case 11:
			return 30;
		case 2:
			return ( IsLeapYear(Y) ? 29 : 28 );
		default:
			return 0;
	}
}

void PrevDate(int& D, int& M, int& Y)
{
	if (D == 1)
	{
		if (M == 1)
		{
			Y--;
			M = 12;
		}
		else
			M--;
		
		D = MonthDays(M, Y);
	}
	else
		D--;
}
