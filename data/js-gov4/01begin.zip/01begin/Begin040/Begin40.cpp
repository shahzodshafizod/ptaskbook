#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <direct.h>

using namespace std;

// { "no": 40, "dat": "2", "ans": "2" }
void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __foldername__[4];
	char __input_filename__[12];
	char __output_filename__[12];
	sprintf(__foldername__, "%03d", __number__);
	sprintf(__input_filename__, "%s\\%s.dat", __foldername__, __foldername__);
	sprintf(__output_filename__, "%s\\%s.ans", __foldername__, __foldername__);
	_mkdir(__foldername__);
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);

	// ====code============================================

    Task("Begin40");

	input_file << fixed << setprecision(2);
	output_file << fixed << setprecision(2);

	double A1, B1, C1, A2, B2, C2;

	pt >> A1 >> B1 >> C1 >> A2 >> B2 >> C2;
	input_file << A1 << ' ' << B1 << ' ' << C1 << endl << A2 << ' ' << B2 << ' ' << C2;

	double D = A1 * B2 - A2 * B1;
	double x = (C1 * B2 - C2 * B1) / D;
	double y = (A1 * C2 - A2 * C1) / D;

	pt << x << y;
	output_file << x << endl << y;

	// ====code============================================

	input_file.close();
	output_file.close();
}
