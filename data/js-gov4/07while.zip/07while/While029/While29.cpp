#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <direct.h>

using namespace std;

// { "no": 29, "dat": "6", "ans": "6" }
void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __foldername__[4];
	char __input_filename__[12];
	char __output_filename__[12];
	sprintf(__foldername__, "%03d", __number__);
	sprintf(__input_filename__, "%s\\%s.dat", __foldername__, __foldername__);
	sprintf(__output_filename__, "%s\\%s.ans", __foldername__, __foldername__);
	_mkdir(__foldername__);
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(6);
	output_file << boolalpha << fixed << setprecision(6);

	// ====code============================================

    Task("While29");
	double eps;

	pt >> eps;
	input_file << eps;

	double next, prev = 1, curr = 2;
	int K = 2;
	do
	{
		K++;
		next = (prev + 2 * curr) / 3;
		prev = curr;
		curr = next;
	}
	while (abs(curr - prev) >= eps);

	pt << K;
	output_file << K << endl;

	pt << prev << curr;
	output_file << prev << ' ' << curr;

	// ====code============================================

	input_file.close();
	output_file.close();
}
