#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

int Quarter(double x, double y);

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8] = "000.dat";
	char __output_filename__[8] = "000.ans";
	int __index__ = 2;
	while (__number__ > 0) {
		__input_filename__[__index__] = __output_filename__[__index__] = char(int('0') + __number__ % 10);
		__number__ /= 10;
		__index__--;
	}
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << boolalpha << fixed << setprecision(2);

	// ====code============================================


    Task("Proc23");
	double x, y;
	int result;

	for (int i = 0; i < 3; i++)
	{
		pt >> x >> y;
		input_file << x << ' ' << y << endl;

		result = Quarter(x, y);

		pt << result;
		output_file << result << endl;
	}

	// ====code============================================

	input_file.close();
	output_file.close();
}

int Quarter(double x, double y)
{
	return ( x > 0 ? y > 0 ? 1 : 4 : y > 0 ? 2 : 3 );
}
