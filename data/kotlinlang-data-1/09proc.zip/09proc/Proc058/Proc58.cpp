#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

struct Point
{
	double x, y;
};

double Area(double xA, double yA, double xB, double yB, double xC, double yC);
double Perim(double xA, double yA, double xB, double yB, double xC, double yC,
			 double& a, double& b, double& c);
double Leng(double xA, double yA, double xB, double yB);

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8] = "000.dat";
	char __output_filename__[8] = "000.ans";
	int __index__ = 2;
	while (__number__ > 0) {
		__input_filename__[__index__] = __output_filename__[__index__] = char(int('0') + __number__ % 10);
		__number__ /= 10;
		__index__--;
	}
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << boolalpha << fixed << setprecision(2);

	// ====code============================================


    Task("Proc58");
	Point A, B, C, D;
	
	pt >> A.x >> A.y;
	input_file << A.x << ' ' << A.y << endl;

	pt >> B.x >> B.y;
	input_file << B.x << ' ' << B.y << endl;

	pt >> C.x >> C.y;
	input_file << C.x << ' ' << C.y << endl;

	pt >> D.x >> D.y;
	input_file << D.x << ' ' << D.y;

	double result;

	result = Area(A.x, A.y, B.x, B.y, C.x, C.y);
	pt << result;
	output_file << result << '\n';

	result = Area(A.x, A.y, B.x, B.y, D.x, D.y);
	pt << result;
	output_file << result << '\n';

	result = Area(A.x, A.y, C.x, C.y, D.x, D.y);
	pt << result;
	output_file << result;

	// ====code============================================

	input_file.close();
	output_file.close();
}

double Area(double xA, double yA, double xB, double yB, double xC, double yC)
{
	double a, b, c;
	double p = Perim(xA, yA, xB, yB, xC, yC, a, b, c) / 2;
	
	return sqrt( p*(p-a)*(p-b)*(p-c) );
}

double Perim(double xA, double yA, double xB, double yB, double xC, double yC,
			 double& a, double& b, double& c)
{
	a = Leng(xA, yA, xB, yB);
	b = Leng(xA, yA, xC, yC);
	c = Leng(xB, yB, xC, yC);

	return a+b+c;
}

double Leng(double xA, double yA, double xB, double yB)
{
	return sqrt( pow(xB - xA, 2) + pow(yB - yA, 2) );
}
