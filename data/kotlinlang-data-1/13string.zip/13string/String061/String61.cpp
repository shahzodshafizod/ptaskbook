#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

struct Word
{
	int index1;
	int index2;
	int length;
};

double round(double, int);
float round(float, int);

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8] = "000.dat";
	char __output_filename__[8] = "000.ans";
	int __index__ = 2;
	while (__number__ > 0) {
		__input_filename__[__index__] = __output_filename__[__index__] = char(int('0') + __number__ % 10);
		__number__ /= 10;
		__index__--;
	}
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << boolalpha << fixed << setprecision(2);

	// ====code============================================


    Task("String61");
	char str[1000];
	
	pt >> str;
	input_file << str;

	int index = 0;
	Word word;
	word.index1 = word.index2 = -1;
	while (str[index] != '\0')
	{
		if (str[index] == '\\')
		{
			if (word.index2 < 0)
				word.index2 = index;
			else
			{
				word.index1 = word.index2;
				word.index2 = index;
			}
		}
		index++;
	}
	
	char* newStr = NULL;
	if (word.index1 < 0)
	{
		newStr = new char [2];
		newStr[0] = '\\';
		newStr[1] = '\0';
	}
	else
	{
		word.index1++;
		word.index2--;
		word.length = word.index2 - word.index1 + 1;
		
		newStr = new char [word.length + 1];
		for (int i = 0, j = word.index1; j <= word.index2; i++, j++)
			newStr[i] = str[j];
		newStr[word.length] = '\0';
	}

	pt << newStr;
	output_file << newStr;

	delete [] newStr;
	newStr = NULL;


	// ====code============================================

	input_file.close();
	output_file.close();
}

double round(double number, int precision) {
	double multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	double half = 0.5 / multiplier;
	double temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

float round(float number, int precision) {
	float multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	float half = 0.5 / multiplier;
	float temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}