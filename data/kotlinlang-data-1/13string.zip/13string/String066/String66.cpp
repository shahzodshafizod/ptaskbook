#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

double round(double, int);
float round(float, int);

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8] = "000.dat";
	char __output_filename__[8] = "000.ans";
	int __index__ = 2;
	while (__number__ > 0) {
		__input_filename__[__index__] = __output_filename__[__index__] = char(int('0') + __number__ % 10);
		__number__ /= 10;
		__index__--;
	}
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << boolalpha << fixed << setprecision(2);

	// ====code============================================

    Task("String66");
	char str[1000];
	
	pt >> str;
	input_file << str;

	int len = 0;
	while (str[len] != '\0')
		len++;

	char* newStr = new char [len];
	int i = 0, j = 0;
	for (; i < len/2; i++)
	{
		newStr[len-1-i] = str[j++];
		newStr[i] = str[j++];
	}
	if (len % 2 != 0)
		newStr[i] = str[j];

	
	for (int i = 0; i < len; i++)
		str[i] = newStr[i];

	delete [] newStr;
	newStr = NULL;

	pt << str;
	output_file << str;

	// ====code============================================

	input_file.close();
	output_file.close();
}

double round(double number, int precision) {
	double multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	double half = 0.5 / multiplier;
	double temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

float round(float number, int precision) {
	float multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	float half = 0.5 / multiplier;
	float temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}