#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

double round(double, int);
float round(float, int);

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8] = "000.dat";
	char __output_filename__[8] = "000.ans";
	int __index__ = 2;
	while (__number__ > 0) {
		__input_filename__[__index__] = __output_filename__[__index__] = char(int('0') + __number__ % 10);
		__number__ /= 10;
		__index__--;
	}
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << boolalpha << fixed << setprecision(2);

	// ====code============================================

    Task("String38");
	char S[1000], S1[1000], S2[1000];
	
	pt >> S >> S1 >> S2;
	input_file << S << endl << S1 << endl << S2;

	int len = 0;
	while (S[len] != '\0')
		len++;

	int S1Len = 0;
	while (S1[S1Len] != '\0')
		S1Len++;

	int S2Len = 0;
	while (S2[S2Len] != '\0')
		S2Len++;

	for (int i = 0; i < len; i++)
	{
		if (S[i] == S1[0])
		{
			int j = 0, k = i;
			bool ok = true;
			while ( (j < S1Len) && (k < len) )
				if (S1[j++] != S[k++])
				{
					ok = false;
					break;
				}
			if ( ok && (j == S1Len) )
			{
				int newLen = len - S1Len + S2Len;
				char* newStr = new char [newLen];
				int index;
				for (index = 0; index < i; index++)
					newStr[index] = S[index];
				for (int j = 0; j < S2Len; j++)
					newStr[index++] = S2[j];
				for (int j = k; j < len; j++)
					newStr[index++] = S[j];

				for (int i = 0; i < newLen; i++)
					S[i] = newStr[i];
				S[newLen] = '\0';

				delete [] newStr;
				newStr = NULL;

				len = newLen;
				i = i - S1Len + S2Len;
			}
		}
	}

	pt << S;
	output_file << S;

	// ====code============================================

	input_file.close();
	output_file.close();
}

double round(double number, int precision) {
	double multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	double half = 0.5 / multiplier;
	double temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

float round(float number, int precision) {
	float multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	float half = 0.5 / multiplier;
	float temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}