#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

double round(double, int);
float round(float, int);

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8] = "000.dat";
	char __output_filename__[8] = "000.ans";
	int __index__ = 2;
	while (__number__ > 0) {
		__input_filename__[__index__] = __output_filename__[__index__] = char(int('0') + __number__ % 10);
		__number__ /= 10;
		__index__--;
	}
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << boolalpha << fixed << setprecision(2);

	// ====code============================================

    Task("Array115");
	
	int N;

	pt >> N;
	input_file << N << endl;

	double* A = new double [N];
	int* I = new int [N];
	for (int i = 0; i < N; i++)
	{
		pt >> A[i];
		input_file << A[i] << ' ';

		I[i] = i;
	}

	int temp;
	for (int i = 0; i < N-1; i++)
	{
		for (int j = 1; j < N-i; j++)
		{
			if (A[I[j]] < A[I[j-1]])
			{
				temp = I[j];
				I[j] = I[j-1];
				I[j-1] = temp;
			}
		}
	}

	for (int i = 0; i < N; i++) {
		pt << I[i]+1;
		output_file << I[i]+1 << ' ';
	}

	delete [] A;
	delete [] I;
	A = 0;
	I = 0;

	// ====code============================================

	input_file.close();
	output_file.close();
}

double round(double number, int precision) {
	double multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	double half = 0.5 / multiplier;
	double temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

float round(float number, int precision) {
	float multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	float half = 0.5 / multiplier;
	float temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}