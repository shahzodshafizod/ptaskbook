#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

struct Point
{
	int x;
	int y;
};

void Swap(Point& a, Point& b);
double round(double, int);
float round(float, int);

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8] = "000.dat";
	char __output_filename__[8] = "000.ans";
	int __index__ = 2;
	while (__number__ > 0) {
		__input_filename__[__index__] = __output_filename__[__index__] = char(int('0') + __number__ % 10);
		__number__ /= 10;
		__index__--;
	}
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << boolalpha << fixed << setprecision(2);

	// ====code============================================



    Task("Array140");
	
	int N;

	pt >> N;
	input_file << N << endl;

	Point* A = new Point [N];
	for (int i = 0; i < N; i++) {
		pt >> A[i].x >> A[i].y;
		input_file << A[i].x << ' ' << A[i].y << endl;
	}

	bool condition;
	for (int i = 0; i < N-1; i++)
	{
		for (int j = 1; j < N-i; j++)
		{
			condition = (A[j-1].x +	A[j-1].y < A[j].x + A[j].y) || (A[j-1].x + A[j-1].y == A[j].x + A[j].y) && (A[j-1].x < A[j].x);
			if (condition)
				Swap(A[j-1], A[j]);
		}
	}

	for (int i = 0; i < N; i++) {
		pt << A[i].x << A[i].y;
		output_file << A[i].x << ' ' << A[i].y << endl;
	}

	delete [] A;
	A = 0;

	// ====code============================================

	input_file.close();
	output_file.close();
}

double round(double number, int precision) {
	double multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	double half = 0.5 / multiplier;
	double temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

float round(float number, int precision) {
	float multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	float half = 0.5 / multiplier;
	float temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

void Swap(Point& a, Point& b)
{
	Point c;
	c.x = a.x;
	c.y = a.y;

	a.x = b.x;
	a.y = b.y;

	b.x = c.x;
	b.y = c.y;
}
