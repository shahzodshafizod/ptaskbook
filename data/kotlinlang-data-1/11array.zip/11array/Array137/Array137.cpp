#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

double round(double, int);
float round(float, int);

struct Point
{
	double x;
	double y;
};
double GetPerim(Point mass[], int index1, int index2, int index3);

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8] = "000.dat";
	char __output_filename__[8] = "000.ans";
	int __index__ = 2;
	while (__number__ > 0) {
		__input_filename__[__index__] = __output_filename__[__index__] = char(int('0') + __number__ % 10);
		__number__ /= 10;
		__index__--;
	}
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << boolalpha << fixed << setprecision(2);

	// ====code============================================



    Task("Array137");

	int N;

	pt >> N;
	input_file << N << endl;

	Point* A = new Point [N];
	for (int i = 0; i < N; i++) {
		pt >> A[i].x >> A[i].y;
		input_file << A[i].x << ' ' << A[i].y << endl;
	}

	int index1 = 0, index2 = 1, index3 = 2;
	double P, maxP = GetPerim(A, index1, index2, index3);
	for (int i = 0; i < N; i++)
	{
		for (int j = i+1; j < N; j++)
		{
			for (int k = j+1; k < N; k++)
			{
				P = GetPerim(A, i, j, k);
				
				if (P > maxP)
				{
					maxP = P;
					index1 = i;
					index2 = j;
					index3 = k;
				}
			}
		}
	}

	pt << maxP;
	output_file << maxP << endl;

	pt << A[index1].x << A[index1].y;
	output_file << A[index1].x << ' ' << A[index1].y << endl;

	pt << A[index2].x << A[index2].y;
	output_file << A[index2].x << ' ' << A[index2].y << endl;

	pt << A[index3].x << A[index3].y;
	output_file << A[index3].x << ' ' << A[index3].y;

	delete [] A;
	A = 0;

	// ====code============================================

	input_file.close();
	output_file.close();
}

double round(double number, int precision) {
	double multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	double half = 0.5 / multiplier;
	double temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

float round(float number, int precision) {
	float multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	float half = 0.5 / multiplier;
	float temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

double GetPerim(Point mass[], int index1, int index2, int index3)
{
	double a = sqrt( pow(mass[index1].x - mass[index2].x, 2) + pow(mass[index1].y - mass[index2].y, 2) );
	double b = sqrt( pow(mass[index1].x - mass[index3].x, 2) + pow(mass[index1].y - mass[index3].y, 2) );
	double c = sqrt( pow(mass[index2].x - mass[index3].x, 2) + pow(mass[index2].y - mass[index3].y, 2) );

	return a + b + c;
}
