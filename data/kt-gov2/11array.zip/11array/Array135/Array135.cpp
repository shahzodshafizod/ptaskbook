#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

double round(double, int);
float round(float, int);

struct Point
{
	double x;
	double y;
};

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8] = "000.dat";
	char __output_filename__[8] = "000.ans";
	int __index__ = 2;
	while (__number__ > 0) {
		__input_filename__[__index__] = __output_filename__[__index__] = char(int('0') + __number__ % 10);
		__number__ /= 10;
		__index__--;
	}
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << boolalpha << fixed << setprecision(2);

	// ====code============================================



    Task("Array135");
	
	int N1;

	pt >> N1;
	input_file << N1 << endl;

	Point* A = new Point [N1];
	for (int i = 0; i < N1; i++) {
		pt >> A[i].x >> A[i].y;
		input_file << A[i].x << ' ' << A[i].y << endl;
	}

	int N2;

	pt >> N2;
	input_file << endl << N2 << endl;

	Point* B = new Point [N2];
	for (int i = 0; i < N2; i++) {
		pt >> B[i].x >> B[i].y;
		input_file << B[i].x << ' ' << B[i].y << endl;
	}

	double length, minLength = sqrt( pow(A[0].x - B[0].x, 2) + pow(A[0].y - B[0].y, 2) );
	int indexA = 0, indexB = 0;
	for (int i = 0; i < N1; i++)
	{
		for (int j = 0; j < N2; j++)
		{
			length = sqrt( pow(A[i].x - B[j].x, 2) + pow(A[i].y - B[j].y, 2) );
			
			if (length < minLength)
			{
				minLength = length;
				indexA = i;
				indexB = j;
			}
		}
	}

	pt << minLength;
	output_file << minLength << endl;

	pt << A[indexA].x << A[indexA].y;
	output_file << A[indexA].x << ' ' << A[indexA].y << endl;

	pt << B[indexB].x << B[indexB].y;
	output_file << B[indexB].x << ' ' << B[indexB].y;

	delete [] A;
	delete [] B;
	A = B = 0;

	// ====code============================================

	input_file.close();
	output_file.close();
}

double round(double number, int precision) {
	double multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	double half = 0.5 / multiplier;
	double temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

float round(float number, int precision) {
	float multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	float half = 0.5 / multiplier;
	float temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}