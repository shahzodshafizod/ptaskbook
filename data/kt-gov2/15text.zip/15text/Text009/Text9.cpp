#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <string>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <direct.h>

using namespace std;

void __copy_to_path__(const char* __path__, const char* filenameFrom);
void __copy_here__(const char* fileNameFrom, const char* filenameTo);
char* __get_filename__(const char* filename, const char* suffix);

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __foldername__[4];
	char __input_filename__[12];
	char __output_filename__[12];
	sprintf(__foldername__, "%03d", __number__);
	sprintf(__input_filename__, "%s\\%s.dat", __foldername__, __foldername__);
	sprintf(__output_filename__, "%s\\%s.ans", __foldername__, __foldername__);
	_mkdir(__foldername__);
	ofstream __input_file__(__input_filename__);
	ofstream __output_file__(__output_filename__);
	__input_file__ << fixed << setprecision(2);
	__output_file__ << boolalpha << fixed << setprecision(2);
	char* __path__ = __get_filename__(__foldername__, "\\");
	
	// ====code============================================

    Task("Text9");
	const int stringSize = 80;
	int K;
	
	pt >> K;
	__input_file__ << K << endl;
	
	char fileName[100], str[stringSize], tempFileName[] = "tempFileName.txt";
	
	pt >> fileName;
	__input_file__ << fileName;
	__copy_to_path__(__path__, fileName);
	
	ifstream file(fileName);
	ofstream tempFile(tempFileName);
	for (int i = 1; true; i++)
	{
		file.getline(str, stringSize);
		if (file.eof())
		{
			file.clear();
			break;
		}
		if (i == K)
			tempFile << endl;
		tempFile << str << endl;
	}
	file.close();
	tempFile.close();
	remove(fileName);
	rename(tempFileName, fileName);

	char *newFileName = __get_filename__(fileName, ".out");
	__copy_here__(fileName, newFileName);
	__copy_to_path__(__path__, newFileName);
	remove(newFileName);
	__output_file__ << newFileName;


	// ====code============================================

	__input_file__.close();
	__output_file__.close();
}

void __copy_to_path__(const char* __path__, const char* filenameFrom) {
	
	char* filenameTo = __get_filename__(__path__, filenameFrom);
	__copy_here__(filenameFrom, filenameTo);
}

void __copy_here__(const char* filenameFrom, const char* filenameTo) {
	
	ifstream fileFrom(filenameFrom, ios::binary);
	ofstream fileTo(filenameTo, ios::binary);

	char c;
	while (true) {
		fileFrom.read(reinterpret_cast<char*>(&c), sizeof(c));
		if (fileFrom.eof()) {
			fileFrom.clear();
			break;
		}
		fileTo.write(reinterpret_cast<const char*>(&c), sizeof(c));
	}

	fileFrom.close();
	fileTo.close();
}

char* __get_filename__(const char* filename, const char* suffix) {

	int fLeng = 0; while (filename[fLeng] != '\0') fLeng++;
	
	int sLeng = 0; while (suffix[sLeng] != '\0') sLeng++;

	char* newFilename = new char [fLeng+sLeng+1]; // + for \0
	int index = 0;

	// 1. copy filename;
	for (; index < fLeng; index++) {
		newFilename[index] = filename[index];
	}
	
	// 2. copy suffix;
	int suffixIndex = 0;
	while (suffix[suffixIndex] != '\0') {
		newFilename[index++] = suffix[suffixIndex++];
	}

	newFilename[index] = '\0';
	
	return newFilename;
}