#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8] = "000.dat";
	char __output_filename__[8] = "000.ans";
	int __index__ = 2;
	while (__number__ > 0) {
		__input_filename__[__index__] = __output_filename__[__index__] = char(int('0') + __number__ % 10);
		__number__ /= 10;
		__index__--;
	}
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << fixed << setprecision(2);

	// ====code============================================

    Task("Begin21");
	double x1, y1, x2, y2, x3, y3;

	pt >> x1 >> y1 >> x2 >> y2 >> x3 >> y3;
	input_file << x1 << endl << y1 << endl << x2 << endl << y2 << endl << x3 << endl << y3;

	double a = sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
	double b = sqrt(pow(x3 - x2, 2) + pow(y3 - y2, 2));
	double c = sqrt(pow(x3 - x1, 2) + pow(y3 - y1, 2));
	double P = a + b + c;
	double p = P / 2;
	double S = sqrt(p * (p - a) * (p - b) * (p - c));

	pt << P << S;
	output_file << P << endl << S;

	// ====code============================================

	input_file.close();
	output_file.close();
}