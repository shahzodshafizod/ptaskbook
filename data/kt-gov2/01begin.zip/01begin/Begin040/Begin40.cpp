#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8] = "000.dat";
	char __output_filename__[8] = "000.ans";
	int __index__ = 2;
	while (__number__ > 0) {
		__input_filename__[__index__] = __output_filename__[__index__] = char(int('0') + __number__ % 10);
		__number__ /= 10;
		__index__--;
	}
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << fixed << setprecision(2);

	// ====code============================================

    Task("Begin40");
	double A1, B1, C1, A2, B2, C2;

	pt >> A1 >> B1 >> C1 >> A2 >> B2 >> C2;
	input_file << A1 << endl << B1 << endl << C1 << endl << A2 << endl << B2 << endl << C2;

	double D = A1 * B2 - A2 * B1;
	double x = (C1 * B2 - C2 * B1) / D;
	double y = (A1 * C2 - A2 * C1) / D;

	pt << x << y;
	output_file << x << endl << y;

	// ====code============================================

	input_file.close();
	output_file.close();
}