#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8] = "000.dat";
	char __output_filename__[8] = "000.ans";
	int __index__ = 2;
	while (__number__ > 0) {
		__input_filename__[__index__] = __output_filename__[__index__] = char(int('0') + __number__ % 10);
		__number__ /= 10;
		__index__--;
	}
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << boolalpha << fixed << setprecision(2);

	// ====code============================================

    Task("Minmax25");
	int N;

	pt >> N;
	input_file << N << endl;

	double prev, curr, zarb, minZarb;
	int index1, index2;

	pt >> prev >> curr;
	input_file << prev << ' ' << curr;

	minZarb = prev * curr;
	index1 = 1;
	index2 = 2;

	for (int i = 3; i <= N; i++)
	{
		prev = curr;

		pt >> curr;
		input_file << ' ' << curr;

		zarb = prev * curr;
		if (zarb < minZarb)
		{
			minZarb = zarb;
			index1 = i-1;
			index2 = i;
		}
	}

	pt << index1 << index2;
	output_file << index1 << ' ' << index2;

	// ====code============================================

	input_file.close();
	output_file.close();
}