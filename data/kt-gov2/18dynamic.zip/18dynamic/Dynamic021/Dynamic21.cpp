#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

void printStack(ofstream &pt, TNode *top);
void printQueue(ofstream &pt, TNode *first, TNode *last);

void Solve()
{
	ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8];
	char __output_filename__[8];
	sprintf(__input_filename__, "%03d.dat", __number__);
	sprintf(__output_filename__, "%03d.ans", __number__);
	ofstream __input_file__(__input_filename__);
	ofstream __output_file__(__output_filename__);
	__input_file__ << fixed << setprecision(2);
	__output_file__ << boolalpha << fixed << setprecision(2);
	

	// ====code============================================


    Task("Dynamic21");
	TNode *P1, *P2, *P3, *P4;
	pt >> P1 >> P2 >> P3 >> P4;
	printQueue(__input_file__, P1, P2);
	__input_file__ << endl;
	printQueue(__input_file__, P3, P4);

	while (P1 != NULL)
	{
		TNode* temp = P1;
		P1 = P1->Next;
		temp->Next = NULL;
		if (P4 == NULL)
			P3 = P4 = temp;
		else
		{
			P4->Next = temp;
			P4 = temp;
		}
		temp = NULL;
	}
	P2 = NULL;
	pt << P3 << P4;
	printQueue(__output_file__, P3, P4);


	// ====code============================================

	__input_file__.close();
	__output_file__.close();
}

void printStack(ofstream &pt, TNode *top) {
	int count = 0;
	TNode* newTop = NULL;
	TNode *newNode, *i;
	for (i = top; i != NULL; i = i->Next) {
		newNode = new TNode();
		newNode->Data = i->Data;
		newNode->Next = newTop;
		newTop = newNode;
		count++;
	}
	pt << count << endl;
	for (i = newTop; i != NULL; i = i->Next) {
		pt << i->Data << ' ';
	}
	i = newTop;
	while (i != NULL) {
		TNode* tempNode = i;
		i = i->Next;
		delete tempNode;
	}
}

void printQueue(ofstream &pt, TNode *first, TNode *last) {
    if (first == NULL) {
        pt << 0;
        return;
    }
    int count = 0;
    for (TNode *i = first; true; ) {
        count++;
        if (i == last) {
            break;
        }
        i = i->Next;
    }
    pt << count << endl;
    for (TNode *i = first; true; ) {
        pt << i->Data << ' ';
        if (i == last) {
            break;
        }
        i = i->Next;
    }
}