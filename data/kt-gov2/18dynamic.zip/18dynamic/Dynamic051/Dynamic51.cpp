#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

void printStack(ofstream &pt, TNode *top);
void printQueue(ofstream &pt, TNode *first, TNode *last);
void printList(ofstream &pt, TNode *first, TNode *last, TNode *current);
void PutNodeBefore(TNode* newNode, TNode* node);

void Solve()
{
	ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8];
	char __output_filename__[8];
	sprintf(__input_filename__, "%03d.dat", __number__);
	sprintf(__output_filename__, "%03d.ans", __number__);
	ofstream __input_file__(__input_filename__);
	ofstream __output_file__(__output_filename__);
	__input_file__ << fixed << setprecision(2);
	__output_file__ << boolalpha << fixed << setprecision(2);
	

	// ====code============================================



    Task("Dynamic51");
	TNode* P1, *P2, *P0;
	pt >> P1 >> P2 >> P0;
	printList(__input_file__, P1, P2, NULL);
	__input_file__ << endl;
	printList(__input_file__, NULL, NULL, P0);
	
	while (P1 != NULL)
	{
		TNode* next = P1->Next;
		PutNodeBefore(P1, P0);
		P1 = next;
	}
	P2 = P0;
	while (P2->Next != NULL)
		P2 = P2->Next;
	P1 = P0;
	while (P1->Prev != NULL)
		P1 = P1->Prev;
	
	pt << P1 << P2;
	printList(__output_file__, P1, P2, NULL);


	// ====code============================================

	__input_file__.close();
	__output_file__.close();
}

void PutNodeBefore(TNode* newNode, TNode* node)
{
	if ( (newNode == NULL) || (node == NULL) )
		return;
	newNode->Next = node;
	newNode->Prev = node->Prev;
	node->Prev = newNode;
	if (newNode->Prev != NULL)
		newNode->Prev->Next = newNode;
}

void printStack(ofstream &pt, TNode *top) {
	int count = 0;
	TNode* newTop = NULL;
	TNode *newNode, *i;
	for (i = top; i != NULL; i = i->Next) {
		newNode = new TNode();
		newNode->Data = i->Data;
		newNode->Next = newTop;
		newTop = newNode;
		count++;
	}
	pt << count << endl;
	for (i = newTop; i != NULL; i = i->Next) {
		pt << i->Data << ' ';
	}
	i = newTop;
	while (i != NULL) {
		TNode* tempNode = i;
		i = i->Next;
		delete tempNode;
	}
}

void printQueue(ofstream &pt, TNode *first, TNode *last) {
    if (first == NULL) {
        pt << 0;
        return;
    }
    int count = 0;
    for (TNode *i = first; true; ) {
        count++;
        if (i == last) {
            break;
        }
        i = i->Next;
    }
    pt << count << endl;
    for (TNode *i = first; true; ) {
        pt << i->Data << ' ';
        if (i == last) {
            break;
        }
        i = i->Next;
    }
}

void printList(ofstream &pt, TNode *first, TNode *last, TNode *current) {
	if (first == NULL) {
		if (current == NULL) {
			first = last;
			while (first != NULL && first->Prev != NULL && first->Prev != last)
				first = first->Prev;
		} else {
			for (first = current; first->Prev != NULL; first = first->Prev) {}
		}
	}
	int count = 0;
	int currentOrderNumber = 0;
	for (TNode *index = first; index != NULL; index = index->Next) {
		count++;
		if (index == current) {
			currentOrderNumber = count;
		}
		if (index->Next == first) break;
	}
	pt << count << ' ' << currentOrderNumber << '\n';
	for (TNode *index = first; index != NULL; index = index->Next) {
		pt << index->Data << ' ';
		if (index == last) {
			break;
		}
		if (index->Next == first) break;
	}
}