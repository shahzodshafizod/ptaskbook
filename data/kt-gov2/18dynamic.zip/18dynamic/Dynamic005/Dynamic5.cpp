#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

void printStack(ofstream& pt, TNode* top);

void Solve()
{
	ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8];
	char __output_filename__[8];
	sprintf(__input_filename__, "%03d.dat", __number__);
	sprintf(__output_filename__, "%03d.ans", __number__);
	ofstream __input_file__(__input_filename__);
	ofstream __output_file__(__output_filename__);
	__input_file__ << fixed << setprecision(2);
	__output_file__ << boolalpha << fixed << setprecision(2);
	

	// ====code============================================


    Task("Dynamic5");
	TNode *P1, *P2;
	pt >> P1;
	printStack(__input_file__, P1);
	
	int D = P1->Data;
	P2 = P1->Next;
	delete P1;
	
	pt << D;
	__output_file__ << D << endl;
	pt << P2;
	printStack(__output_file__, P2);


	// ====code============================================

	__input_file__.close();
	__output_file__.close();
}

void printStack(ofstream& pt, TNode* top) {
	int count = 0;
	TNode* newTop = NULL;
	TNode *newNode, *i;
	for (i = top; i != NULL; i = i->Next) {
		newNode = new TNode();
		newNode->Data = i->Data;
		newNode->Next = newTop;
		newTop = newNode;
		count++;
	}
	pt << count << endl;
	for (i = newTop; i != NULL; i = i->Next) {
		pt << i->Data << ' ';
	}
	i = newTop;
	while (i != NULL) {
		TNode* tempNode = i;
		i = i->Next;
		delete tempNode;
	}
}