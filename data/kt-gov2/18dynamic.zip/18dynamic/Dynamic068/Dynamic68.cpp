#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

class TList
{
public:
	TNode* First;
	TNode* Last;
	TNode* Current;

	TList(TNode* P1, TNode* P2, TNode* P3)
		: First(P1), Last(P2), Current(P3)
	{}
	
	TNode* DeleteCurrent();
	void AddBeforeCurrent(TNode*);
	bool IsEmptyList() const;
	void InsertList(TList&);
	void ToFirst();
	void ToLast();
};

void printStack(ofstream &pt, TNode *top);
void printQueue(ofstream &pt, TNode *first, TNode *last);
void printList(ofstream &pt, TNode *first, TNode *last, TNode *current);
void printListCurrents(ofstream &pt, TNode *currentX, TNode *currentY);

void Solve()
{
	ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8];
	char __output_filename__[8];
	sprintf(__input_filename__, "%03d.dat", __number__);
	sprintf(__output_filename__, "%03d.ans", __number__);
	ofstream __input_file__(__input_filename__);
	ofstream __output_file__(__output_filename__);
	__input_file__ << fixed << setprecision(2);
	__output_file__ << boolalpha << fixed << setprecision(2);
	

	// ====code============================================



    Task("Dynamic68");
	TNode *P1, *P2, *P3, *P4, *P5, *P6;
	pt >> P1 >> P2 >> P3 >> P4 >> P5 >> P6;
	printList(__input_file__, P1, P2, P3);
	__input_file__ << endl;
	printList(__input_file__, P4, P5, P6);

	TList list1(P1, P2, P3);
	TList list2(P4, P5, P6);
	list2.InsertList(list1);
	
	pt << list2.First << list2.Last << list2.Current;
	printList(__output_file__, list2.First, list2.Last, list2.Current);


	// ====code============================================

	__input_file__.close();
	__output_file__.close();
}

void TList::InsertList(TList& L)
{
	TNode* current = L.First;
	L.ToFirst();
	while ( !L.IsEmptyList() )
	{
		TNode* node = L.DeleteCurrent();
		this->AddBeforeCurrent(node);
		if (this->First == this->Current)
			this->First = node;
	}
	if (current != NULL)
		this->Current = current;
}

TNode* TList::DeleteCurrent()
{
	TNode* current = this->Current;
	if (this->Current == NULL)
		return NULL;
	this->Current = this->Current->Next;
	if (current->Prev != NULL)
		current->Prev->Next = current->Next;
	if (current->Next != NULL)
		current->Next->Prev = current->Prev;
	if (this->First == current)
		this->First = this->First->Next;
	if (this->Last == current)
		this->Last = this->Last->Prev;
	current->Next = current->Prev = NULL;
	return current;
}

void TList::AddBeforeCurrent(TNode* node)
{
	if (node == NULL)
		return;
	node->Next = this->Current;
	node->Prev = NULL;
	if (this->Current != NULL)
	{
		node->Prev = this->Current->Prev;
		this->Current->Prev = node;
		if (node->Prev != NULL)
			node->Prev->Next = node;
		if (this->First == this->Last)
			this->First = node;
	}
	else
		this->First = this->Last = this->Current = node;
}

bool TList::IsEmptyList() const
{
	return ( (this->Current == NULL) && (this->First == NULL) && (this->Last == NULL) );
}

void TList::ToFirst()
{
	this->Current = this->First;
}

void TList::ToLast()
{
	this->Current = this->Last;
}

void printStack(ofstream &pt, TNode *top) {
	int count = 0;
	TNode* newTop = NULL;
	TNode *newNode, *i;
	for (i = top; i != NULL; i = i->Next) {
		newNode = new TNode();
		newNode->Data = i->Data;
		newNode->Next = newTop;
		newTop = newNode;
		count++;
	}
	pt << count << endl;
	for (i = newTop; i != NULL; i = i->Next) {
		pt << i->Data << ' ';
	}
	i = newTop;
	while (i != NULL) {
		TNode* tempNode = i;
		i = i->Next;
		delete tempNode;
	}
}

void printQueue(ofstream &pt, TNode *first, TNode *last) {
    if (first == NULL) {
        pt << 0;
        return;
    }
    int count = 0;
    for (TNode *i = first; true; ) {
        count++;
        if (i == last) {
            break;
        }
        i = i->Next;
    }
    pt << count << endl;
    for (TNode *i = first; true; ) {
        pt << i->Data << ' ';
        if (i == last) {
            break;
        }
        i = i->Next;
    }
}

void printList(ofstream &pt, TNode *first, TNode *last, TNode *current) {
	if (first == NULL) {
		if (current == NULL) {
			first = last;
			while (first != NULL && first->Prev != NULL && first->Prev != last)
				first = first->Prev;
		} else {
			for (first = current; first->Prev != NULL; first = first->Prev) {}
		}
	}
	int count = 0;
	int currentOrderNumber = 0;
	for (TNode *index = first; index != NULL; index = index->Next) {
		count++;
		if (index == current) {
			currentOrderNumber = count;
		}
		if (index->Next == first) break;
	}
	pt << count << ' ' << currentOrderNumber << '\n';
	for (TNode *index = first; index != NULL; index = index->Next) {
		pt << index->Data << ' ';
		if (index == last) {
			break;
		}
		if (index->Next == first) break;
	}
}

void printListCurrents(ofstream &pt, TNode *currentX, TNode *currentY) {
	if (currentX == NULL && currentY == NULL) {
		pt << "0 0\n";
		return;
	}
	TNode *first = currentX;
	if (first == NULL) first = currentY;
	while (first->Prev != NULL) first = first->Prev;

	TNode *last = currentY;
	if (last == NULL) last = currentX;
	while (last->Next != NULL) last = last->Next;

	int count = 0;
	int currentXIndex = 0, currentYIndex = 0;
	for (TNode *index = first; index != NULL; index = index->Next) {
		count++;
		if (index == currentX) {
			currentXIndex = count;
		}
		if (index == currentY) {
			currentYIndex = count;
		}
		if (index->Next == first) break;
	}
	pt << currentXIndex << ' ' << currentYIndex << '\n';
	pt << count << " 0\n";
	for (TNode *index = first; index != NULL; index = index->Next) {
		pt << index->Data << ' ';
		if (index == last) {
			break;
		}
		if (index->Next == first) break;
	}
}