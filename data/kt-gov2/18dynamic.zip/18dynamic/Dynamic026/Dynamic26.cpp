#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

struct TQueue
{
	TNode* Head;
	TNode* Tail;
};

void Enqueue(TQueue& Q, int D);
void printStack(ofstream &pt, TNode *top);
void printQueue(ofstream &pt, TNode *first, TNode *last);

void Solve()
{
	ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8];
	char __output_filename__[8];
	sprintf(__input_filename__, "%03d.dat", __number__);
	sprintf(__output_filename__, "%03d.ans", __number__);
	ofstream __input_file__(__input_filename__);
	ofstream __output_file__(__output_filename__);
	__input_file__ << fixed << setprecision(2);
	__output_file__ << boolalpha << fixed << setprecision(2);
	

	// ====code============================================



    Task("Dynamic26");
	TNode* P1, *P2;
	pt >> P1 >> P2;
	printQueue(__input_file__, P1, P2);

	int N, number;
	pt >> N;
	__input_file__ << endl << N << endl;

	TQueue queue;
	queue.Head = P1;
	queue.Tail = P2;
	
	for (int i = 1; i <= N; i++)
	{
		pt >> number;
		__input_file__ << number << ' ';

		Enqueue(queue, number);
	}

	pt << queue.Head << queue.Tail;
	printQueue(__output_file__, queue.Head, queue.Tail);


	// ====code============================================

	__input_file__.close();
	__output_file__.close();
}

void Enqueue(TQueue& Q, int D)
{
	TNode* newTail = new TNode;
	newTail->Data = D;
	newTail->Next = NULL;
	if (Q.Tail == NULL)
		Q.Head = Q.Tail = newTail;
	else
	{
		Q.Tail->Next = newTail;
		Q.Tail = newTail;
	}
	newTail = NULL;
}

void printStack(ofstream &pt, TNode *top) {
	int count = 0;
	TNode* newTop = NULL;
	TNode *newNode, *i;
	for (i = top; i != NULL; i = i->Next) {
		newNode = new TNode();
		newNode->Data = i->Data;
		newNode->Next = newTop;
		newTop = newNode;
		count++;
	}
	pt << count << endl;
	for (i = newTop; i != NULL; i = i->Next) {
		pt << i->Data << ' ';
	}
	i = newTop;
	while (i != NULL) {
		TNode* tempNode = i;
		i = i->Next;
		delete tempNode;
	}
}

void printQueue(ofstream &pt, TNode *first, TNode *last) {
    if (first == NULL) {
        pt << 0;
        return;
    }
    int count = 0;
    for (TNode *i = first; true; ) {
        count++;
        if (i == last) {
            break;
        }
        i = i->Next;
    }
    pt << count << endl;
    for (TNode *i = first; true; ) {
        pt << i->Data << ' ';
        if (i == last) {
            break;
        }
        i = i->Next;
    }
}