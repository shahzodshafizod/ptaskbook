#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

double round(double, int);
float round(float, int);

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8] = "000.dat";
	char __output_filename__[8] = "000.ans";
	int __index__ = 2;
	while (__number__ > 0) {
		__input_filename__[__index__] = __output_filename__[__index__] = char(int('0') + __number__ % 10);
		__number__ /= 10;
		__index__--;
	}
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	// input_file << fixed << setprecision(2);
	// output_file << fixed << setprecision(2);

	// ====code============================================

    Task("If23");
	int x1, y1, x2, y2, x3, y3, x4, y4;

	pt >> x1 >> y1 >> x2 >> y2 >> x3 >> y3;
	input_file << x1 << endl << y1 << endl << x2 << endl << y2 << endl << x3 << endl << y3;

	if (x1 == x2)
		x4 = x3;
	else if (x1 == x3)
		x4 = x2;
	else
		x4 = x1;
	if (y1 == y2)
		y4 = y3;
	else if (y1 == y3)
		y4 = y2;
	else
		y4 = y1;

	pt << x4 << y4;
	output_file << x4 << endl << y4;

	// ====code============================================

	input_file.close();
	output_file.close();
}

double round(double number, int precision) {
	double multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	double half = 0.5 / multiplier;
	double temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

float round(float number, int precision) {
	float multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	float half = 0.5 / multiplier;
	float temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}