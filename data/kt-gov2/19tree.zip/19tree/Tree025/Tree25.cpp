#include "pt4.h"
#include <fstream>
#include <iomanip>
using namespace std;

enum TChar {SPACE, LEFT, CENTER, RIGHT, NUMBER};

class Field {
	private: const int cellWidth;
	private: int height;
	private: int width;
	private: TNode*** matrix;
	private: TChar** chars;

	public: Field(TNode*, int, int);
	private: void init(TNode*);
	public: ~Field();
	private: void fillMatrix(TNode*, int, int&);
	private: void fillChars();
	private: void printChars(ofstream&, string, int);
	private: TNode* getNexTNode(int, int);
	private: int getSpaces(int);
	public: void display(ofstream&, TNode* node = NULL);
	public: int* getWay(TNode*, int*);
};

class Tree {
	private: TNode* Root;
	private: TNode* current;
	private: int nodeCount;
	private: int level;
	private: Field* field;

	public: Tree(TNode*); //Contructor
	public: ~Tree(); //Destructor
	private: void free();
	public: void display(ofstream&, TNode* node = NULL);
	public: int getNodeCount(); //Tree 2
	public: void setNodeCount(); //Tree 2
	private: void setLevel(int currentLevel = 0);
	public: int getLevel(); //Tree 9
	public: void printWay(TNode*, ofstream&);
};

void MakeTree(TNode** P, int N, ofstream&);

void Solve()
{
    Task("Tree25");

	ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8];
	char __output_filename__[8];
	sprintf(__input_filename__, "%03d.dat", __number__);
	sprintf(__output_filename__, "%03d.ans", __number__);
	ofstream __input_file__(__input_filename__);
	ofstream __output_file__(__output_filename__);
	__input_file__ << fixed << setprecision(2);
	__output_file__ << boolalpha << fixed << setprecision(2);


	// ====code============================================
    int N;
	pt >> N;
	__input_file__ << N << endl;
	TNode* P1 = NULL;
	MakeTree(&P1, N, __input_file__);
	pt << P1;

	Tree tr(P1);
	tr.display(__output_file__);
    // ====code============================================

	__input_file__.close();
	__output_file__.close();
}

void MakeTree(TNode** P, int N, ofstream& file)
{
	TNode* node = *P;
	for (int i = 1; i <= N; i++)
	{
		TNode* temp = new TNode;
		pt >> temp->Data;
		file << temp->Data << ' ';
		temp->Left = temp->Right = NULL;
		if (node == NULL)
			*P = temp;
		else
			node->Right = temp;
		node = temp;
	}
}

Field::Field(TNode* node, int _height, int _width)
	: cellWidth(4) {
	this->height = _height;
	this->width = _width;
	this->init(node);
}

void Field::init(TNode* node) {
	this->matrix = new TNode** [this->height];
	this->chars = new TChar* [this->height];
	for (int i = 0; i < this->height; ++i) {
		this->matrix[i] = new TNode* [this->width];
		this->chars[i] = new TChar [this->width];
		for (int j = 0; j < this->width; ++j) {
			this->matrix[i][j] = NULL;
			this->chars[i][j] = SPACE;
		}
	}
	int index = 0;
	this->fillMatrix(node, 0, index);
	this->fillChars();
}

Field::~Field() {
	for (int i = 0; i < this->height; ++i) {
		delete [] this->matrix[i];
		delete [] this->chars[i];
	}
	delete [] this->matrix;
	delete [] this->chars;
}

void Field::fillMatrix(TNode* node, int row, int& col) {
	if (node == NULL) {
		return;
	}
	fillMatrix(node->Left, row+1, col);
	this->matrix[row][col++] = node;
	fillMatrix(node->Right, row+1, col);
}

void Field::fillChars() {
	for (int i = 0; i < this->height; ++i) {
		for (int j = 0; j < this->width; ++j) {
			if (this->matrix[i][j] == NULL) {
				continue;
			}
			this->chars[i][j] = NUMBER;
			if (this->matrix[i][j]->Left != NULL) {
				for (int k = j-1; k >= 0; --k) {
					if (this->matrix[i+1][k] == NULL) {
						this->chars[i][k] = CENTER;
						continue;
					}
					this->chars[i][k] = LEFT;
					break;
				}
			}
			if (this->matrix[i][j]->Right != NULL) {
				for (++j; j < this->width; ++j) {
					if (this->matrix[i+1][j] == NULL) {
						this->chars[i][j] = CENTER;
						continue;
					}
					this->chars[i][j] = RIGHT;
					break;
				}
			}
		}
	}
}

void Field::printChars(ofstream &pt, string C, int count) {
	for (int i = 0; i < count; ++i) {
		pt << C;
	}
}

TNode* Field::getNexTNode(int i, int j) {
	for (; j < this->width; ++j) {
		if (this->matrix[i][j] != NULL) {
			return this->matrix[i][j];
		}
	}
	return NULL;
}

int Field::getSpaces(int number) {
	int spaces = this->cellWidth;
	if (number < 0) {
		number *= -1;
		--spaces;
	}
	while (number > 0) {
		number /= 10;
		--spaces;
	}
	return spaces;
}

void Field::display(ofstream &pt, TNode* node) {
	int data, spaces;
	TNode* nexTNode;

	string left = "┌";
	string center = "─";
	string right = "┐";
	string space = " ";

	for (int i = 0; i < this->height; ++i) {
		for (int j = 0; j < this->width; ++j) {
			switch (this->chars[i][j]) {
				case SPACE:
					this->printChars(pt, space, this->cellWidth);
					break;
				case LEFT:
					nexTNode = getNexTNode(i, j);
					data = nexTNode->Data;
					spaces = nexTNode == node ? 2 : getSpaces(data);
					this->printChars(pt, space, spaces/2);
					this->printChars(pt, left, 1);
					this->printChars(pt, center, this->cellWidth-1);
					break;
				case CENTER:
					this->printChars(pt, center, this->cellWidth);
					break;
				case RIGHT:
					this->printChars(pt, center, this->cellWidth-1);
					this->printChars(pt, right, 1);
					this->printChars(pt, space, spaces/2 + spaces%2);
					break;
				case NUMBER:
					if (this->matrix[i][j]->Left == NULL) {
						data = this->matrix[i][j]->Data;
						spaces = this->matrix[i][j] == NULL ? this->cellWidth-2 : getSpaces(data);
						this->printChars(pt, space, spaces/2);
					}

					pt << data;

					if (this->matrix[i][j]->Right == NULL) {
						this->printChars(pt, space, spaces/2 + spaces%2);
					}
					break;
			}
		}
		pt << endl;
	}
}

int* Field::getWay(TNode* node, int* count) {
    *count = 0;
    if (node == NULL) {
        return NULL;
    }
    /// 1. get root's rowIndex, colIndex;
    int rootRow = 0, rootCol = 0;
    while (rootCol < this->width) {
        if (this->matrix[rootRow][rootCol] != NULL) {
            break;
        }
        rootCol++;
    }
    /// 2. get node's rowIndex, colIndex;
    int nodeRow = 0, nodeCol = 0;
    for (; nodeRow < this->height; nodeRow++) {
        for (nodeCol = 0; nodeCol < this->width; nodeCol++) {
            if (this->matrix[nodeRow][nodeCol] == node) {
                break;
            }
        }
        if (this->matrix[nodeRow][nodeCol] == node) {
            break;
        }
    }
    /// 3. while currentNode is not equal to the node, move to the next;
    *count = nodeRow + 1;
    int *way = new int[*count];
    int index = 0;
    TNode *root = this->matrix[rootRow][rootCol];
    bool moved;
    while (root != node && rootRow <= nodeRow && index < *count) {
        /// 1. check vertically: and go the left or right;
        moved = false;
        if (rootCol > nodeCol && root->Left != NULL) {
            /// 1.1. move left;
            for (int col = 0; col < this->width; col++) {
                if (this->matrix[rootRow+1][col] != NULL && this->matrix[rootRow+1][col] == root->Left) {
                    root = this->matrix[rootRow+1][col];
                    rootRow++;
                    rootCol = col;
                    way[index++] = 1;
                    moved = true;
                    break;
                }
            }
        } else if (root->Right != NULL) {
            /// 1.2. move right;
            for (int col = this->width-1; col >= 0; col--) {
                if (this->matrix[rootRow+1][col] != NULL && this->matrix[rootRow+1][col] == root->Right) {
                    root = this->matrix[rootRow+1][col];
                    rootRow++;
                    rootCol = col;
                    way[index++] = 2;
                    moved = true;
                    break;
                }
            }
        }
        if (!moved) {
            break;
        }
    }
    way[index] = 0;
    return way;
}

// TREE

Tree::Tree(TNode *root) {
	this->Root = root;
	this->current = root;
	this->field = NULL;
	this->nodeCount = 0;
	this->level = -1;
}

Tree::~Tree() {
	if (this->current != this->Root) {
		this->current = this->Root;
	}
	this->free();
	delete this->field;
}

void Tree::free() {
	if (this->current == NULL) {
		this->current = this->Root;
		return;
	}
	TNode* node = this->current;

	this->current = node->Left;
	this->free();
	this->current = node->Right;
	this->free();

	this->current = node;
	delete this->current;
	this->nodeCount--;
	this->current = NULL;
}

void Tree::display(ofstream &pt, TNode* node) {
	pt << this->getLevel()+1 << endl;
	if (this->Root == NULL) {
		return;
	}
	if (this->field == NULL) {
		this->field = new Field(this->Root, this->getLevel()+1, this->getNodeCount()+1);
	}
	this->field->display(pt, node);
	this->current = this->Root;
}

void Tree::setNodeCount() {
	if (this->current == NULL) {
		this->current = this->Root;
		return;
	}
	this->nodeCount++;
	TNode* node = this->current;
	this->current = node->Left;
	this->setNodeCount();
	this->current = node->Right;
	this->setNodeCount();
}

int Tree::getNodeCount() {
	if (this->nodeCount == 0) {
		this->setNodeCount();
	}
	return this->nodeCount;
}

void Tree::setLevel(int currentLevel) {
	if (this->current == NULL) {
		this->current = this->Root;
		return;
	}
	if (currentLevel > this->level) {
		this->level = currentLevel;
	}
	TNode* node = this->current;
	this->current = node->Left;
	this->setLevel(currentLevel+1);
	this->current = node->Right;
	this->setLevel(currentLevel+1);
}

int Tree::getLevel() {
	if (this->level < 0) {
		this->setLevel();
	}
	return this->level;
}

int* getWay(TNode *node) {
    if (node == NULL) {
        return NULL;
    }
    int count = 0;
    for (TNode *i = node; i != NULL; i = i->Parent) {
        count++;
    }
    int *way = new int[count];
    count--;
    TNode *parent;
    while (node != NULL) {
        parent = node->Parent;
        if (parent->Left == node) {
            way[count] = 1;
        } else {
            way[count] = 2;
        }
        count--;
        node = node->Parent;
    }
    return way;
}

void Tree::printWay(TNode* node, ofstream& file) {
    int count;
	int *way = this->field->getWay(node, &count);
	if (way == NULL) {
        return;
	}
	for (int index = 0; index < count; index++) {
        file << way[index] << ' ';
	}
	file << endl;
}

