#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

double round(double, int);
float round(float, int);
void NextDate(int& D, int& M, int& Y);
int MonthDays(int M, int Y);
bool IsLeapYear(int Y);

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8] = "000.dat";
	char __output_filename__[8] = "000.ans";
	int __index__ = 2;
	while (__number__ > 0) {
		__input_filename__[__index__] = __output_filename__[__index__] = char(int('0') + __number__ % 10);
		__number__ /= 10;
		__index__--;
	}
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	output_file << boolalpha;

	// ====code============================================


    Task("Proc55");
	int d, m, y;
	for (int i = 1; i < 4; i++)
	{
		pt >> d >> m >> y;
		input_file << d << ' ' << m << ' ' << y << endl;

		NextDate(d, m, y);

		pt << d << m << y;
		output_file << d << ' ' << m << ' ' << y << endl;
	}

	// ====code============================================

	input_file.close();
	output_file.close();
}

double round(double number, int precision) {
	double multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	double half = 0.5 / multiplier;
	double temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

float round(float number, int precision) {
	float multiplier = 1;
	for (int i = 0; i < precision; i++) {
		multiplier *= 10;
	}
	float half = 0.5 / multiplier;
	float temp = (number + half) * multiplier;
	return floor(temp) / multiplier;
}

void NextDate(int& D, int& M, int& Y)
{
	if (D == MonthDays(M, Y))
	{
		if (M == 12)
		{
			Y++;
			M = 1;
		}
		else
			M++;
		D = 1;
	}
	else
		D++;
}

int MonthDays(int M, int Y)
{
	switch (M)
	{
		case 1: case 3: case 5: case 7: case 8: case 10: case 12:
			return 31;
		case 4: case 6: case 9: case 11:
			return 30;
		case 2:
			return ( IsLeapYear(Y) ? 29 : 28 );
	}
}

bool IsLeapYear(int Y)
{
	if (Y % 400 == 0)
		return true;

	else if (Y % 100 == 0)
		return false;
	
	else if (Y % 4 == 0)
		return true;

	else
		return false;
}
