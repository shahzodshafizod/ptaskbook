#include <windows.h>
#pragma hdrstop
#include "pt4.h"

#include <sstream>
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

void Solve()
{
    ifstream __raqami_tartibi__("number.txt");
	int __number__;
	__raqami_tartibi__ >> __number__;
	__raqami_tartibi__.close();
	ofstream __save_raqami_tartibi__("number.txt");
	__save_raqami_tartibi__ << (__number__+1);
	__save_raqami_tartibi__.close();
	char __input_filename__[8] = "000.dat";
	char __output_filename__[8] = "000.ans";
	int __index__ = 2;
	while (__number__ > 0) {
		__input_filename__[__index__] = __output_filename__[__index__] = char(int('0') + __number__ % 10);
		__number__ /= 10;
		__index__--;
	}
	ofstream input_file(__input_filename__);
	ofstream output_file(__output_filename__);
	input_file << fixed << setprecision(2);
	output_file << fixed << setprecision(2);

	// ====code============================================

    Task("Case12");
	const double PI = 3.14;
	int index;

	pt >> index;
	input_file << index << endl;

	double value, R, D, L, S;

	pt >> value;
	input_file << value;

	switch (index)
	{
		case 1:
			R = value;
			D = 2 * R;
			L = 2 * PI * R;
			S = PI * R * R;
			break;
		case 2:
			D = value;
			R = D / 2;
			L = 2 * PI * R;
			S = PI * R * R;
			break;
		case 3:
			L = value;
			R = L / (2 * PI);
			D = 2 * R;
			S = PI * R * R;
			break;
		case 4:
			S = value;
			R = sqrt(S / PI);
			D = 2 * R;
			L = 2 * PI * R;
			break;
	}
	
	if (index != 1) {
		pt << R;
		output_file << R << endl;
	}

	if (index != 2) {
		pt << D;
		output_file << D << endl;
	}

	if (index != 3) {
		pt << L;
		output_file << L << endl;
	}

	if (index != 4) {
		pt << S;
		output_file << S << endl;
	}

	// ====code============================================

	input_file.close();
	output_file.close();
}